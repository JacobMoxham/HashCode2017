
public class Video {
	int id;
	int size;
	public Video(int id, int size){
		this.id = id;
		this.size = size;
	}
}
