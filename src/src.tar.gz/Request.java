
public class Request {
	Endpoint endpoint;
	Video video;
	int number;
	public Request(Endpoint endpoint, Video video, int number){
		this.endpoint=endpoint;
		this.video=video;
		this.number=number;
	}
}
